#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <FreeImage.h>
#include <vector>;

int main()
{
	//Initialize the window lib
	//Glfwinit initializes glfw
	if (glfwInit() == GL_FALSE)
	{
		return -1;
	}
	
	//create a windowed mode window
	GLFWwindow* GLFWwindowPtr = glfwCreateWindow(800, 600, "SatchEngine DSA1", NULL, NULL);

	//make it the currently active window, or quit.
	if (GLFWwindowPtr != nullptr)
	{
		glfwMakeContextCurrent(GLFWwindowPtr);
	}
	else
	{
		glfwTerminate();
		return -1;
	}

	//Initialize GLEW or quit
	if (glewInit() != GLEW_OK)
	{
		glfwTerminate();
		return -1;
	}
	//Define model vert location
	std::vector<glm::vec3> locs = { { .9, .9, 0 }, //top right
	{ -.9, .9, 0 }, //top left
	{ -.9, -.9, 0 },//bot left
	{ .9, -.9, 0 } };//bot right

					 //connect the dots
	std::vector <unsigned int>
		locInds = { 0, 1, 2,
		0, 2, 3 };
	unsigned int vertCount = locInds.size();

	//process model data
	//duplicate vert into a single buffer
	std::vector<glm::vec3> vertBufData(vertCount);

	for (unsigned int i = 0; i < vertCount; i++)
	{
		vertBufData[i] = locs[locInds[i]];
	}

	//Setup GLuint = hold the num identifying the array and buffer generating
	GLuint vertArr;
	GLuint vertBuf;

	//generating a buffer
	glGenVertexArrays(1, &vertArr);
	glGenBuffers(1, &vertBuf);

	//bind the buffer
	//glBindBuffer controls which array and buffer is active
	glBindVertexArray(vertArr);
	glBindBuffer(GL_ARRAY_BUFFER, vertBuf);
	

	//store data in the buff
	//glBufferData copies specified data into currently bound buffer
	glBufferData(GL_ARRAY_BUFFER,				//where to copy 
		sizeof(glm::vec3) * vertCount,	// # bytes to copy
		&vertBufData[0],				//where to copy from
		GL_STATIC_DRAW);				//to OpenGL

										//describe the buffer layout
										//enable the attribute
	glEnableVertexAttribArray(0); //attribute index - 0
								  //setup the attribute
	glVertexAttribPointer(
		0,					//Attribute index - 0 in this case
		3,					//Number of componets (x, y, z)
		GL_FLOAT,			//Type of Data
		GL_FALSE,			//Should we normalize the data?
		sizeof(glm::vec3),	//Stride ( Bytes per vert)
		0);					//Offset to this attribute
							//unbind when finished editing
	glBindVertexArray(0);

	//change window color
	//only set once
	glClearColor(0.392f, 0.584f, 0.929f, 1.0f);

	//GAME LOOP
	//Loop until the user closes the window
	while (!glfwWindowShouldClose(GLFWwindowPtr))
	{
		//Update physical sims
		//Draw buffered models
		//Process input/window events

		//clear the canvas
		glClear(GL_COLOR_BUFFER_BIT);
		//rendering game objs
		glBindVertexArray(vertArr);
		glDrawArrays(GL_TRIANGLES, 0, vertCount);
		glBindVertexArray(0);
		//unbind an object after drawing it

		//swap the front (whatthe screen displays) and the back (what openGL draws) buffers
		glfwSwapBuffers(GLFWwindowPtr);

		glfwPollEvents();
	}

	//terminate glfw to avoid mem loss
	glfwTerminate();
	return 0;
}